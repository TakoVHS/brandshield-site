# Brandshield GitHub Pages Site (docs/)

Эта папка предназначена для публикации сайта через GitHub Pages **из папки `/docs`** на ветке `main`.

## Что делать
1) Скопируй папку `docs/` из этого архива в корень репозитория `web3-brandshield-platform`.
2) Закоммить и запушь.
3) В GitHub: **Settings → Pages → Build and deployment**
   - Source: **Deploy from a branch**
   - Branch: `main`
   - Folder: `/docs`
4) Подожди 1–3 минуты — сайт станет доступен.

## Подсказка про URL
Если это Project Pages, адрес будет:
`https://<user>.github.io/<repo>/`

Если это User/Org Pages (репо `<user>.github.io`), адрес будет:
`https://<user>.github.io/`

В таком случае в `docs/_config.yml` поставь `baseurl: ""`.
Для project pages обычно тоже можно оставить `baseurl: ""` — ссылки в меню относительные.

## Редактирование
- Главная: `docs/index.md`
- Audit Pack: `docs/audit-pack.md`
- Free Snapshot: `docs/snapshot.md`
- Radar: `docs/radar.md`
- Compliance/Privacy/Methodology: `docs/compliance.md`, `docs/privacy.md`, `docs/methodology.md`

## Необязательное (но полезно)
- Добавь `docs/CNAME` для собственного домена.
- Замени `docs/assets/og.png` на свою картинку (1200×630).
